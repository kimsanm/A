import 'package:flutter_test/flutter_test.dart';
import 'package:telegram_pro/main.dart';

void main() {
  testWidgets('renders Telegram Pro UI', (tester) async {
    await tester.pumpWidget(const TelegramProApp());
    expect(find.text('Telegram Pro'), findsOneWidget);
  });
}
