import 'package:flutter/material.dart';
import 'tdlib_bridge.dart';

void main() => runApp(const TelegramProApp());

class TelegramProApp extends StatelessWidget {
  const TelegramProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Telegram Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff229ed9)), useMaterial3: true),
      darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff229ed9), brightness: Brightness.dark), useMaterial3: true),
      themeMode: ThemeMode.system,
      home: const ChatsPage(),
    );
  }
}

class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  final bridge = TdlibBridge();
  final search = TextEditingController();
  String status = 'TDLib native engine not configured';
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    try {
      final s = await bridge.getStatus();
      if (mounted) setState(() => status = s);
    } catch (_) {
      if (mounted) setState(() => status = 'UI demo — native TDLib is not connected');
    }
  }

  Future<void> _login() async {
    setState(() => busy = true);
    try {
      final result = await bridge.startLogin();
      if (mounted) setState(() => status = result);
    } catch (e) {
      if (mounted) setState(() => status = 'TDLib bridge unavailable. Follow README setup.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final demoChats = [
      ('Saved Messages', 'Keep notes and files here', Icons.bookmark, 'S'),
      ('Telegram Tips', 'Welcome to Telegram Pro', Icons.campaign, 'T'),
      ('Family Group', 'Photos and messages appear here', Icons.groups, 'F'),
      ('Work Team', 'Voice notes and files appear here', Icons.work, 'W'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Telegram Pro', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(tooltip: 'Search', onPressed: () => showSearch(context: context, delegate: ChatSearchDelegate(demoChats.map((e) => e.$1).toList())), icon: const Icon(Icons.search)),
          IconButton(tooltip: 'Settings', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(status: status, onLogin: _login))), icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity, margin: const EdgeInsets.fromLTRB(12, 4, 12, 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            const Icon(Icons.info_outline),
            const SizedBox(width: 10),
            Expanded(child: Text(status, maxLines: 2, overflow: TextOverflow.ellipsis)),
            TextButton(onPressed: busy ? null : _login, child: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Connect')),
          ]),
        ),
        Expanded(child: ListView.separated(
          itemCount: demoChats.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
          itemBuilder: (context, i) {
            final c = demoChats[i];
            return ListTile(
              leading: CircleAvatar(radius: 25, child: Icon(c.$3)),
              title: Text(c.$1, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(c.$2, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(title: c.$1, bridge: bridge))),
            );
          },
        )),
      ]),
      floatingActionButton: FloatingActionButton(onPressed: () => _login(), child: const Icon(Icons.person_add_alt_1)),
    );
  }
}

class ChatPage extends StatefulWidget {
  final String title;
  final TdlibBridge bridge;
  const ChatPage({super.key, required this.title, required this.bridge});
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final List<String> messages = [];
  bool recording = false;

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty) return;
    setState(() => messages.add(text));
    input.clear();
    try {
      await widget.bridge.sendText(widget.title, text);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo only: connect TDLib to send real messages.')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title), actions: [
      IconButton(tooltip: 'Voice call', onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Calls are not implemented in this starter.'))), icon: const Icon(Icons.call_outlined)),
      IconButton(tooltip: 'More', onPressed: () {}, icon: const Icon(Icons.more_vert)),
    ]),
    body: Column(children: [
      Expanded(child: messages.isEmpty
        ? const Center(child: Text('Your conversation will appear here after TDLib is connected.'))
        : ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (_, i) => Align(
            alignment: Alignment.centerRight,
            child: Container(margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(16)),
              child: Text(messages[i]))))),
      SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(8, 4, 8, 8), child: Row(children: [
        IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Attach media after TDLib integration.'))), icon: const Icon(Icons.attach_file)),
        Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Message', border: OutlineInputBorder(), isDense: true), onSubmitted: (_) => send())),
        IconButton(onPressed: () => setState(() => recording = !recording), icon: Icon(recording ? Icons.stop_circle_outlined : Icons.mic_none)),
        IconButton(onPressed: send, icon: const Icon(Icons.send)),
      ]))),
    ]),
  );
}

class SettingsPage extends StatelessWidget {
  final String status;
  final Future<void> Function() onLogin;
  const SettingsPage({super.key, required this.status, required this.onLogin});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: ListView(children: [
      const ListTile(leading: Icon(Icons.person_outline), title: Text('Telegram account'), subtitle: Text('Official Telegram API / TDLib')),
      ListTile(leading: const Icon(Icons.link), title: const Text('Connection status'), subtitle: Text(status)),
      ListTile(leading: const Icon(Icons.login), title: const Text('Connect account'), onTap: onLogin),
      const ListTile(leading: Icon(Icons.dark_mode_outlined), title: Text('Theme'), subtitle: Text('Follows system Light/Dark setting')),
      const ListTile(leading: Icon(Icons.notifications_outlined), title: Text('Notifications'), subtitle: Text('Requires native notification + TDLib update integration')),
      const ListTile(leading: Icon(Icons.security_outlined), title: Text('Security'), subtitle: Text('Never share your login code or API hash')),
    ]),
  );
}

class ChatSearchDelegate extends SearchDelegate<String> {
  final List<String> chats;
  ChatSearchDelegate(this.chats);
  @override
  List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override
  Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => ListView(children: chats.where((c) => c.toLowerCase().contains(query.toLowerCase())).map((c) => ListTile(title: Text(c), onTap: () => close(context, c))).toList());
  @override
  Widget buildSuggestions(BuildContext context) => buildResults(context);
}
