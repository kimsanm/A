import 'package:flutter/services.dart';

/// Flutter/native boundary. This starter intentionally does not fake Telegram network access.
/// Implement these methods in MainActivity after building and packaging official TDLib.
class TdlibBridge {
  static const _channel = MethodChannel('telegram_pro/tdlib');

  Future<String> getStatus() async =>
      await _channel.invokeMethod<String>('status') ?? 'TDLib native engine not configured';

  Future<String> startLogin() async =>
      await _channel.invokeMethod<String>('startLogin') ?? 'Login flow not configured';

  Future<void> sendText(String chatTitle, String text) =>
      _channel.invokeMethod<void>('sendText', {'chatTitle': chatTitle, 'text': text});

  Future<void> sendFile(String chatTitle, String path) =>
      _channel.invokeMethod<void>('sendFile', {'chatTitle': chatTitle, 'path': path});
}
