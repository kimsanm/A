package com.example.telegram_pro

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "telegram_pro/tdlib"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                // Deliberately explicit: a real Telegram client requires official TDLib Java
                // bindings AND matching native libtdjni.so for each target ABI.
                when (call.method) {
                    "status" -> result.success("UI demo — TDLib native library not bundled")
                    "startLogin" -> result.error(
                        "TDLIB_NOT_CONFIGURED",
                        "Build and bundle official TDLib Android Java/JNI libraries first. See README.",
                        null
                    )
                    "sendText", "sendFile" -> result.error(
                        "TDLIB_NOT_CONFIGURED",
                        "Real messaging is disabled until TDLib is integrated.",
                        null
                    )
                    else -> result.notImplemented()
                }
            }
    }
}
